module.exports={
    MomgoURI: 'mongodb+srv://kabiesi:adeola1100@cluster0.g8hqa.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'
}