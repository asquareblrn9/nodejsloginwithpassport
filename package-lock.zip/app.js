const express = require('express')
const expressLayouts = require('express-ejs-layouts')
//mongoose

const mongoose = require('mongoose')
const app=express()

//DBconfig
const db= require('./config/keys').MomgoURI

//connect to mongoose
mongoose.connect(db, {useNewUrlParser: true})
.then(()=>console.log('MOngoDB connected'))
.catch(err => console.log(err))
//EJS
app.use(expressLayouts)
app.set('view engine', 'ejs')

//bodyparser
app.use(express.urlencoded({extended: false}))

//routes 
app.use('/', require('./routes/index'))
app.use('/users', require('./routes/users'))


const PORT = process.env.PORT || 5000
app.listen(PORT, console.log(`server started om port ${PORT}`))